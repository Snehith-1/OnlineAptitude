CREATE DATABASE  IF NOT EXISTS `onlineexam` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `onlineexam`;
-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: onlineexam
-- ------------------------------------------------------
-- Server version	5.7.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer` (
  `Ans_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Ans1` char(1) DEFAULT NULL,
  `Ans2` char(1) DEFAULT NULL,
  `Ans3` char(1) DEFAULT NULL,
  `Ans4` char(1) DEFAULT NULL,
  `Ans5` char(1) DEFAULT NULL,
  `Ans6` char(1) DEFAULT NULL,
  `Ans7` char(1) DEFAULT NULL,
  `Ans8` char(1) DEFAULT NULL,
  `Ans9` char(1) DEFAULT NULL,
  `Ans10` char(1) DEFAULT NULL,
  `Ans11` char(1) DEFAULT NULL,
  `Ans12` char(1) DEFAULT NULL,
  `Ans13` char(1) DEFAULT NULL,
  `Ans14` char(1) DEFAULT NULL,
  `Ans15` char(1) DEFAULT NULL,
  `Ans16` char(1) DEFAULT NULL,
  `Ans17` char(1) DEFAULT NULL,
  `Ans18` char(1) DEFAULT NULL,
  `Ans19` char(1) DEFAULT NULL,
  `Ans20` char(1) DEFAULT NULL,
  `Ans21` char(1) DEFAULT NULL,
  `Ans22` char(1) DEFAULT NULL,
  `Ans23` char(1) DEFAULT NULL,
  `Ans24` char(1) DEFAULT NULL,
  `Ans25` char(1) DEFAULT NULL,
  `Question_Type` char(1) DEFAULT NULL,
  PRIMARY KEY (`Ans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (1,'A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','B','A','A','A','A','A','A','A','A','1'),(2,'B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','2'),(3,'C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','3'),(4,'D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','D','4');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam`
--

DROP TABLE IF EXISTS `exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam` (
  `exam_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(16) DEFAULT NULL,
  `question_type` varchar(16) DEFAULT NULL,
  `ans_1` varchar(16) DEFAULT NULL,
  `ans_2` varchar(16) DEFAULT NULL,
  `ans_3` varchar(16) DEFAULT NULL,
  `ans_4` varchar(16) DEFAULT NULL,
  `ans_5` varchar(16) DEFAULT NULL,
  `ans_6` varchar(16) DEFAULT NULL,
  `ans_7` varchar(16) DEFAULT NULL,
  `ans_8` varchar(16) DEFAULT NULL,
  `ans_9` varchar(16) DEFAULT NULL,
  `ans_10` varchar(16) DEFAULT NULL,
  `ans_11` varchar(16) DEFAULT NULL,
  `ans_12` varchar(16) DEFAULT NULL,
  `ans_13` varchar(16) DEFAULT NULL,
  `ans_14` varchar(16) DEFAULT NULL,
  `ans_15` varchar(16) DEFAULT NULL,
  `ans_16` varchar(16) DEFAULT NULL,
  `ans_17` varchar(16) DEFAULT NULL,
  `ans_18` varchar(16) DEFAULT NULL,
  `ans_19` varchar(16) DEFAULT NULL,
  `ans_20` varchar(16) DEFAULT NULL,
  `ans_21` varchar(16) DEFAULT NULL,
  `ans_22` varchar(16) DEFAULT NULL,
  `ans_23` varchar(16) DEFAULT NULL,
  `ans_24` varchar(16) DEFAULT NULL,
  `ans_25` varchar(16) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `attended` varchar(45) DEFAULT NULL,
  `notattended` varchar(45) DEFAULT NULL,
  `correct` varchar(45) DEFAULT NULL,
  `wrong` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam`
--

LOCK TABLES `exam` WRITE;
/*!40000 ALTER TABLE `exam` DISABLE KEYS */;
INSERT INTO `exam` VALUES (145,'40','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','B','B','C','D','2021-04-21','Compared','25','0','21','4'),(146,'41','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','B','C','D','B','D','D','D','C','C','2021-04-21','Compared','25','0','16','9'),(147,'42','1','A','A','A','A','A','A','A','A','A','A','C','B','D','D','D','B','B','D','B','C','D','C','C','C','C','2021-04-21','Compared','25','0','10','15'),(148,'43','1','A','A','A','A','A','A','A','A','A','','A','A','A','A','A','A','A','C','B','C','C','B','B','C','B','2021-04-21','Compared','25','0','16','9'),(149,'44','1','A','A','A','A','A','A','D','B','C','D','D','D','C','B','D','D','D','C','C','B','B','B','C','D','B','2021-04-21','Compared','25','0','16','9'),(150,'45','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','2021-04-21','Compared','25','0','25','0'),(151,'46','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','B','B','B','B','2021-04-21','Compared','25','0','21','4'),(152,'47','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','B','B','C','C','B','2021-04-21','Compared','25','0','20','5'),(153,'48','1','A','A','A','A','A','A','A','A','A','A','A','C','C','B','C','C','C','D','C','C','C','C','C','C','B','2021-04-21','Compared','25','0','11','14'),(154,'49','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','C','C','C','C','C','C','B','C','2021-04-22','Compared','25','0','17','8'),(155,'50','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','C','C','B','C','B','B','B','2021-04-22','Compared','25','0','18','7'),(156,'51','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','B','B','C','C','C','B','C','C','B','2021-04-22','Compared','25','0','16','9'),(157,'52','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','','','D','D','B','C','B','2021-04-22','Compared','25','0','18','7'),(158,'44','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','','','','','','','','','','2021-04-22','Compared','25','0','16','9'),(159,'56','1','A','A','A','A','A','','','A','A','A','A','A','A','A','A','','','','','','','','','','','2021-04-23','Compared','25','0','13','12'),(160,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(161,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(162,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(163,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(164,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(165,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(166,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(167,'','1','','','','','','','','','','','','','','','','','','','','','','','','A','','2021-04-23','Compared','25','0','0','25'),(168,'','1','A','A','','','','','','','','','','','','','','','','','','','','','','','','2021-04-23','Compared','25','0','0','25'),(169,'57','1','A','B','B','A','A','C','B','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','2021-04-23','Compared','25','0','25','0'),(170,'57','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','2021-04-23','Compared','25','0','25','0'),(171,'57','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','2021-04-23','Compared','25','0','25','0'),(172,'57','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','2021-04-23','Compared','25','0','25','0'),(173,'66','1','A','A','A','A','A','A','A','A','A','A','A','','','','','','','','','','','','','','','2021-04-23','Compared','25','0','11','14'),(174,'67','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','','','','','','','','','','','','2021-04-25','Compared','25','0','14','11'),(175,'','1','A','A','A','','','','','','','','','','','','','','','','','','','','','','','2021-04-28','Compared','25','0','0','25'),(176,'70','1','A','A','','','','','','','','','','','','','','','','','','','','','','','','2021-04-28','Compared','25','0','2','23'),(177,'71','1','A','A','A','A','A','A','A','A','','','','','','','','','','','','','','','','','','2021-04-28','Compared','25','0','8','17'),(178,'72','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','','','','','','','','','','','2021-04-28','Compared','25','0','15','10'),(179,'73','1','A','A','A','A','A','A','A','A','A','A','','','','','','','','','','','','','','','','2021-04-28','Compared','25','0','10','15'),(180,'74','1','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','','','','2021-04-28','Compared','25','0','22','3'),(181,'75','1','A','A','A','A','A','A','A','A','A','A','A','','A','A','A','A','','','','','','','','','','2021-04-29','Compared','25','0','15','10'),(182,'76','1','A','A','A','A','A','','','','','','','','','','','','','','','','','','','','','2021-04-29','Compared','25','0','5','20'),(183,'77','1','A','A','A','A','A','A','A','A','','','','','','','','','','','','','','','','','','2021-04-29','Compared','25','0','8','17'),(184,'79','1','A','A','','','','','','','','','','','','','','','','','','','','','','','','2021-05-03','Compared','25','0','2','23'),(185,'','','B','B','','','','','','','','','','','','','','','','','','','','','','','','2021-05-03','Compared','25','0','0','25'),(186,'78','1','C','C','C','','','','','','','','','','','','','','','','','','','','','','','2021-05-03','Compared','25','0','0','25'),(187,'81','1','A','A','A','B','B','B','B','B','B','B','B','B','B','A','B','B','B','B','B','B','B','B','B','B','B','2021-05-04','Compared','25','0','5','20'),(188,'85','  2 ','C','C','C','C','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','0','25'),(189,'86','1','A','A','A','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','3','22'),(190,'','  4 ','','','','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','0','25'),(191,'87','  4 ','A','A','A','A','A','A','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','0','25'),(192,'88','  3 ','C','C','C','C','C','C','C','C','C','C','C','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','11','14'),(193,'89','  3 ','C','C','C','C','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','4','21'),(194,'90','  2 ','A','A','A','A','B','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','1','24'),(195,'91','  4 ','D','D','D','D','D','D','D','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','7','18'),(196,'92','  1 ','A','A','A','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','3','22'),(197,'93','  2 ','B','B','B','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','3','22'),(198,'94','  3 ','C','C','C','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','3','22'),(199,'95','  4 ','D','D','D','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','3','22'),(200,'96','  2 ','B','B','','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','2','23'),(201,'97','  1 ','A','A','','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','2','23'),(202,'98','  3 ','C','C','','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','2','23'),(203,'99','  4 ','D','D','','','','','','','','','','','','','','','','','','','','','','','','2021-05-04','Compared','25','0','2','23'),(204,'100','  4 ','D','D','D','','','','','','','','','','','','','','','','','','','','','','','2021-05-07','Compared','25','0','3','22'),(205,'101','  3 ','C','C','C','','','','','','','','','','','','','','','','','','','','','','','2021-05-07','Compared','25','0','3','22'),(206,'102','  2 ','B','B','B','','','','','','','','','','','','','','','','','','','','','','','2021-05-07','Compared','25','0','3','22'),(207,'103','  1 ','A','A','A','','','','','','','','','','','','','','','','','','','','','','','2021-05-07','Compared','25','0','3','22');
/*!40000 ALTER TABLE `exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registration` (
  `registration_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_name` varchar(45) DEFAULT NULL,
  `reg_no` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `historyofarrears` double(13,2) DEFAULT NULL,
  `tenthpercent` double(13,2) DEFAULT NULL,
  `twelfthpercent` double(13,2) DEFAULT NULL,
  `cgpa` double(13,2) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `priority_1` varchar(45) DEFAULT NULL,
  `priority_2` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`registration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration`
--

LOCK TABLES `registration` WRITE;
/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` VALUES (40,'A SNEHITH','0001','BE-ECE',0.00,90.00,77.00,8.00,NULL,'Core Developement','R & D'),(41,'V VIJAY KUMAR','0002','BE-ECE',0.00,70.00,77.00,8.00,NULL,'QC-Analyst','R & D'),(42,'kumar','0003','BE-CSE',0.00,90.00,78.00,9.00,NULL,'QC-Analyst','R & D'),(43,'B VAMSI','0004','BE-CSE',0.00,70.00,76.00,6.00,'2021-04-21','QC-Analyst','Onsite Support'),(44,'J SAI PAVAN','0005','BE-ECE',0.00,90.00,80.00,8.00,'2021-04-21','Priority 1','Priority 2'),(45,'A MOHAN','16751A0407','BE-MECH',0.00,70.00,80.00,8.00,'2021-04-21','QC-Analyst','Onsite Support'),(46,'A ARJUN','16751A0410','BE-IT',0.00,87.00,80.00,8.00,'2021-04-21','QC-Analyst','R & D'),(47,'VENKATESTH','16751A0449','BE-CSE',0.00,90.00,80.00,9.00,'2021-04-21','QC-Analyst','Core Developement'),(48,'C SATHEESH','16751A0450','BE-EEE',0.00,78.00,76.00,8.00,'2021-04-21','Core Developement','R & D'),(49,'V THANOJ KUMAR','16751A0411','BE-ECE',0.00,70.00,78.00,8.00,'2021-04-22','Core Developement','Onsite Support'),(50,'P PRASAD','16751A0401','BE-CSE',0.00,87.00,78.00,8.00,'2021-04-22','Core Developement','Onsite Support'),(51,' A SUJAY','16751A0452','BE-ECE',0.00,90.00,80.00,8.00,'2021-04-22','Core Developement','Inhouse Support'),(52,'M prasad','0001','BE-EEE',0.00,87.00,78.00,9.00,'2021-04-22','Pre-Sales Support','QC-Analyst'),(53,'M PRAKESH','0005','BE-CSE',0.00,88.00,78.00,9.00,'2021-04-22','R & D','Onsite Support'),(54,'prasad','0005','BE-EEE',0.00,90.00,78.00,8.00,'2021-04-22','R & D','Inhouse Support'),(55,'prasad','0005','BE-IT',0.00,90.00,78.00,8.00,'2021-04-22','R & D','Inhouse Support'),(56,' A MOHAN KRISHNA','16751A0453','BE-ECE',0.00,85.00,80.00,8.00,'2021-04-23','Core Developement','R & D'),(57,'Lokesh','16751F0035','MCA',0.00,77.00,55.00,8.00,'2021-04-23','Core Developement','R & D'),(58,'S PAVAN ','16751A0410','BE-ECE',0.00,90.00,80.00,8.00,'2021-04-23','QC-Analyst','R & D'),(59,'S PAVAN ','16751A0407','BE-ECE',0.00,90.00,80.00,8.00,'2021-04-23','QC-Analyst','R & D'),(60,' S PAVAN','16751A0403','BE-ECE',0.00,78.00,80.00,8.00,'2021-04-23','QC-Analyst','Inhouse Support'),(61,'kumar','16751A0407','BE-EEE',0.00,90.00,70.00,8.00,'2021-04-23','Core Developement','R & D'),(62,'A PREM KUMAR','16751A0404','BE-ECE',0.00,88.00,80.00,8.00,'2021-04-23','QC-Analyst','Inhouse Support'),(63,'RAMESH','16751A0405','BE-ECE',0.00,90.00,70.00,6.00,'2021-04-23','Core Developement','R & D'),(64,'A MOHAN','16751A0407','BE-CSE',0.00,88.00,76.00,7.00,'2021-04-23','Core Developement','Inhouse Support'),(65,'prasad','16751A0407','BE-IT',0.00,88.00,76.00,7.00,'2021-04-23','Core Developement','Inhouse Support'),(66,'A SAI KUMAR','16751A0406','BE-ECE',0.00,90.00,80.00,8.00,'2021-04-23','Core Developement','R & D'),(67,'A.SNEHITH NAIDU','16751A0422','BE-ECE',0.00,80.00,75.00,8.33,'2021-04-25','QC-Analyst','R & D'),(68,' A SUJAY','16751A0413','BE-ECE',0.00,78.00,70.00,8.33,'2021-04-28','QC-Analyst','QC-Analyst'),(69,'A MOHAN','16751A0420','BE-CSE',0.00,88.00,76.00,6.00,'2021-04-28','QC-Analyst','R & D'),(70,'A KIRAN','16751A0421','BE-ECE',0.00,88.00,70.00,9.00,'2021-04-28','Pre-Sales Support','R & D'),(71,'A PRASANTH','16751A0426','BE-ECE',0.00,90.00,80.00,8.33,'2021-04-28','QC-Analyst','Marketing'),(72,'DHARANI KUMAR','16751A0415','BE-ECE',0.00,78.00,70.00,8.00,'2021-04-28','Pre-Sales Support','Pre-Sales Support'),(73,'A .SURYA PRAKESH','0011','BE-ECE',0.00,78.00,70.00,7.88,'2021-04-28','Onsite Support','R & D'),(74,'A AMAR','16751A0429','BE-ECE',0.00,88.00,80.00,8.00,'2021-04-28','QC-Analyst','Core Developement'),(75,'C.THIRUMALESH','16751A0431','BE-ECE',0.00,90.00,80.00,9.00,'2021-04-29','QC-Analyst','R & D'),(76,'A KIRSH','16751A0437','BE-ECE',0.00,88.00,77.00,8.00,'2021-04-29','QC-Analyst','R & D'),(77,'A.PRASAD KUMAR','1675','BE-ECE',0.00,90.00,80.00,8.20,'2021-04-29','Core Developement','R & D'),(78,'kumar','16','BE-ECE',0.00,78.00,76.00,8.00,'2021-05-03','QC-Analyst','Inhouse Support'),(79,'murali','17','BE-ECE',0.00,90.00,78.00,8.00,'2021-05-03','QC-Analyst','Inhouse Support'),(80,'prasad','18','BE-ECE',0.00,70.00,78.00,6.00,'2021-05-03','QC-Analyst','Inhouse Support'),(81,'kumar','19','BE-ECE',0.00,88.00,70.00,8.00,'2021-05-04','QC-Analyst','R & D'),(82,'naveen','20','BE-ECE',0.00,78.00,76.00,8.00,'2021-05-04','QC-Analyst','R & D'),(83,'prasad','21','BE-ECE',0.00,90.00,78.00,8.33,'2021-05-04','Core Developement','R & D'),(84,'lokesh','22','BE-ECE',0.00,78.00,80.00,8.33,'2021-05-04','Core Developement','R & D'),(85,'surya','23','BE-ECE',0.00,90.00,80.00,6.00,'2021-05-04','Core Developement','R & D'),(86,'B VAMSI','24','BE-ECE',0.00,90.00,77.00,8.33,'2021-05-04','QC-Analyst','R & D'),(87,'uday','25','BE-ECE',0.00,88.00,70.00,8.33,'2021-05-04','Core Developement','R & D'),(88,'Rajesh','26','BE-ECE',0.00,88.00,77.00,8.00,'2021-05-04','QC-Analyst','R & D'),(89,'NARESH','30','BE-ECE',0.00,90.00,80.00,8.33,'2021-05-04','Core Developement','R & D'),(90,'RAMESH','31','BE-ECE',0.00,90.00,80.00,8.33,'2021-05-04','QC-Analyst','R & D'),(91,'prasad','34','BE-ECE',0.00,87.00,70.00,8.33,'2021-05-04','QC-Analyst','R & D'),(92,'DHANUSH','37','BE-ECE',0.00,70.00,76.00,6.00,'2021-05-04','QC-Analyst','R & D'),(93,'RAKESH','38','BE-ECE',0.00,78.00,77.00,7.00,'2021-05-04','Core Developement','R & D'),(94,'MOHAN KRISHNA','39','BE-ECE',0.00,70.00,80.00,8.00,'2021-05-04','Pre-Sales Support','R & D'),(95,'DURGA','40','BE-ECE',0.00,78.00,78.00,8.33,'2021-05-04','Core Developement','Inhouse Support'),(96,'ONE','41','BE-ECE',0.00,78.00,80.00,8.00,'2021-05-04','QC-Analyst','R & D'),(97,'TWO','42','BE-ECE',0.00,88.00,76.00,8.33,'2021-05-04','Core Developement','R & D'),(98,'THREE','43','BE-ECE',0.00,70.00,78.00,8.00,'2021-05-04','QC-Analyst','Inhouse Support'),(99,'FOUR','44','BE-ECE',0.00,90.00,80.00,6.00,'2021-05-04','QC-Analyst','R & D'),(100,'abhi','12','BE-ECE',0.00,88.00,80.00,8.00,'2021-05-07','Core Developement','R & D'),(101,'VISHNU','46','BE-ECE',0.00,90.00,80.00,8.33,'2021-05-07','Core Developement','Inhouse Support'),(102,'GANESH','47','BE-ECE',0.00,70.00,77.00,6.00,'2021-05-07','QC-Analyst','R & D'),(103,'DHARANI','48','BE-ECE',0.00,87.00,78.00,8.33,'2021-05-07','Core Developement','R & D');
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'onlineexam'
--

--
-- Dumping routines for database 'onlineexam'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-22 12:47:40
